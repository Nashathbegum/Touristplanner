<?php
/**
 * Include after calling require_once includes/functions.php
 * Optional $page_title variable can be set before including this.
 */
$plan_count = count(plan_ids());
$current = basename($_SERVER['SCRIPT_NAME']);
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title><?= isset($page_title) ? h($page_title) . ' — ' : '' ?>Kekirawa Day Planner</title>
<link rel="stylesheet" href="<?= isset($in_admin) ? '../css/style.css' : 'css/style.css' ?>">
</head>
<body>
<header class="site">
  <div class="wrap">
    <a class="brand" href="<?= isset($in_admin) ? '../index.php' : 'index.php' ?>">
      Wewa &amp; Way <small>KEKIRAWA DAY PLANNER</small>
    </a>
    <nav class="site">
      <?php if (!isset($in_admin)): ?>
        <a href="index.php" class="<?= $current === 'index.php' ? 'active' : '' ?>">Places</a>
        <a href="plan.php" class="<?= $current === 'plan.php' ? 'active' : '' ?>">My Plan<?= $plan_count ? ' (' . $plan_count . ')' : '' ?></a>
        <a href="admin/login.php">Admin</a>
      <?php else: ?>
        <a href="../index.php">View Site</a>
        <?php if (is_admin()): ?>
          <a href="dashboard.php" class="<?= $current === 'dashboard.php' ? 'active' : '' ?>">Dashboard</a>
          <a href="logout.php">Log out</a>
        <?php endif; ?>
      <?php endif; ?>
    </nav>
  </div>
</header>
<main>
  <div class="wrap">
