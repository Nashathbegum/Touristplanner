<?php
require_once __DIR__ . '/../config/db.php';

session_start();

function h($str) {
    return htmlspecialchars($str ?? '', ENT_QUOTES, 'UTF-8');
}

function all_categories() {
    $db = get_db();
    return $db->query('SELECT * FROM categories ORDER BY name')->fetchAll();
}

function get_places($category_id = null) {
    $db = get_db();
    if ($category_id) {
        $stmt = $db->prepare(
            'SELECT p.*, c.name AS category_name FROM places p
             JOIN categories c ON c.id = p.category_id
             WHERE p.category_id = ?
             ORDER BY p.name'
        );
        $stmt->execute([$category_id]);
    } else {
        $stmt = $db->query(
            'SELECT p.*, c.name AS category_name FROM places p
             JOIN categories c ON c.id = p.category_id
             ORDER BY p.name'
        );
    }
    return $stmt->fetchAll();
}

function get_place($id) {
    $db = get_db();
    $stmt = $db->prepare(
        'SELECT p.*, c.name AS category_name FROM places p
         JOIN categories c ON c.id = p.category_id
         WHERE p.id = ?'
    );
    $stmt->execute([$id]);
    return $stmt->fetch();
}

function plan_ids() {
    return $_SESSION['plan'] ?? [];
}

function is_admin() {
    return !empty($_SESSION['admin_id']);
}

function require_admin() {
    if (!is_admin()) {
        header('Location: login.php');
        exit;
    }
}
