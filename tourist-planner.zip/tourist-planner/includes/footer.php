  </div>
</main>
<footer class="site">
  <div class="wrap">
    Local Tourist Day-Visit Planner — ITE2953 Programming Project &middot; built for the Kekirawa area
  </div>
</footer>
</body>
</html>
