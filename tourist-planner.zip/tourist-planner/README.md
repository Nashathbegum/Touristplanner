# Kekirawa Day Planner
### ITE2953 Programming Project — Local Tourist Day-Visit Planner and Information System

A small PHP + MySQL web application that helps a visitor plan a one-day trip to
places within 25km of Kekirawa, Sri Lanka. Built as a starting point for the
ITE2953 individual project — **you should adapt the seed data, styling, and
features to your own stakeholder research before submitting.**

## Tech stack
- PHP 8+ (plain PHP, PDO for MySQL — no framework)
- MySQL / MariaDB
- Vanilla HTML/CSS/JS + Leaflet.js (OpenStreetMap) for the map
- No build tools required

## Features
- **Tourist**: browse places, filter by category, view full details (description,
  opening times, distance, travel tips), view each place on a map, get directions,
  and build a one-day visit plan (add/remove/reorder places, see total distance).
- **Admin**: login, add / edit / delete places.

## Setup (XAMPP / local MySQL)

1. Copy the whole `tourist-planner` folder into your XAMPP `htdocs` folder
   (or any folder your local PHP server serves).
2. Start Apache and MySQL from the XAMPP control panel.
3. Open phpMyAdmin (`http://localhost/phpmyadmin`), click **Import**, and
   import `database/schema.sql`. This creates the `tourist_planner` database,
   tables, an admin login, and 10 sample places.
4. Check `config/db.php` — the defaults (`root` user, no password) match a
   standard XAMPP install. Edit if your setup differs.
5. Visit `http://localhost/tourist-planner/` in your browser.
6. Admin panel: `http://localhost/tourist-planner/admin/login.php`
   Default login — **username:** `admin` **password:** `admin123`
   (change this in the `admin_users` table before submitting/deploying).

## Folder structure
```
tourist-planner/
├── config/db.php          Database connection settings
├── database/schema.sql    Tables + seed data (10 sample places)
├── includes/              Shared header, footer, helper functions
├── css/style.css          All styling
├── index.php              Place list + category filter
├── place.php              Single place details + map
├── plan.php                One-day plan builder (session-based)
├── add_to_plan.php        Add/remove a place from the plan
└── admin/                 Login + CRUD for managing places
```

## Customizing for your own submission
- **Replace the seed data** in `database/schema.sql` with your own 10+ places,
  verified against your actual stakeholder consultation (categories can include
  religious, nature, heritage, cultural, recreational, dining, or just useful
  local spots/junctions — they don't need to be famous).
- Update the `<title>` / brand name in `includes/header.php` if you want a
  different project name.
- The visit plan currently lives in the PHP session (resets when the browser
  session ends) — this satisfies "simple one-day visit plan" without needing
  user accounts. You can extend it to save to the database if you want plans
  to persist.
- Coordinates: right-click any spot on openstreetmap.org → "Show address" to
  get accurate latitude/longitude for each place.

## Notes for your SRS / viva
- Passwords are stored with `password_hash()` / verified with `password_verify()`
  (bcrypt) — worth mentioning under security in your SRS.
- All database queries use PDO prepared statements to prevent SQL injection.
- All user-facing output is escaped with `htmlspecialchars()` to prevent XSS.
- The map uses Leaflet.js + OpenStreetMap tiles — free, no API key required
  (worth noting as a design decision vs. Google Maps).
