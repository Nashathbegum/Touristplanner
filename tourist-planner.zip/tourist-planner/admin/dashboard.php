<?php
require_once __DIR__ . '/../includes/functions.php';
$in_admin = true;
require_admin();

$page_title = 'Dashboard';
$places = get_places();

include __DIR__ . '/../includes/header.php';
?>

<div class="detail-head">
  <div>
    <p class="eyebrow">Signed in as <?= h($_SESSION['admin_username']) ?></p>
    <h1>Manage places</h1>
  </div>
  <a class="btn solid" href="add_place.php">+ Add new place</a>
</div>

<?php if (isset($_GET['deleted'])): ?>
  <div class="alert ok">Place deleted.</div>
<?php endif; ?>
<?php if (isset($_GET['saved'])): ?>
  <div class="alert ok">Place saved.</div>
<?php endif; ?>

<table class="admin">
  <thead>
    <tr><th>Name</th><th>Category</th><th>Distance</th><th>Updated</th><th></th></tr>
  </thead>
  <tbody>
    <?php foreach ($places as $p): ?>
      <tr>
        <td><?= h($p['name']) ?></td>
        <td><?= h($p['category_name']) ?></td>
        <td><?= h($p['distance_km']) ?> km</td>
        <td><?= h($p['updated_at']) ?></td>
        <td class="actions">
          <a class="btn small" href="edit_place.php?id=<?= (int)$p['id'] ?>">Edit</a>
          <a class="btn small danger" href="delete_place.php?id=<?= (int)$p['id'] ?>"
             onclick="return confirm('Delete this place? This cannot be undone.');">Delete</a>
        </td>
      </tr>
    <?php endforeach; ?>
  </tbody>
</table>

<?php include __DIR__ . '/../includes/footer.php'; ?>
