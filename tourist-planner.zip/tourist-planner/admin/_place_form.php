<?php
/**
 * Expects $place (array or null) and $categories to be set before include.
 * Renders the add/edit place form. The parent file handles the POST logic.
 */
$place = $place ?? [
    'name' => '', 'category_id' => '', 'description' => '', 'opening_times' => '',
    'travel_tips' => '', 'distance_km' => '', 'latitude' => '', 'longitude' => '', 'image_url' => ''
];
?>
<form class="stack" method="post">
  <div class="field">
    <label for="name">Place name</label>
    <input type="text" id="name" name="name" required value="<?= h($place['name']) ?>">
  </div>

  <div class="field">
    <label for="category_id">Category</label>
    <select id="category_id" name="category_id" required>
      <option value="">Select a category</option>
      <?php foreach ($categories as $cat): ?>
        <option value="<?= (int)$cat['id'] ?>" <?= (string)$place['category_id'] === (string)$cat['id'] ? 'selected' : '' ?>>
          <?= h($cat['name']) ?>
        </option>
      <?php endforeach; ?>
    </select>
  </div>

  <div class="field">
    <label for="description">Description</label>
    <textarea id="description" name="description" required><?= h($place['description']) ?></textarea>
  </div>

  <div class="row-2">
    <div class="field">
      <label for="opening_times">Opening times</label>
      <input type="text" id="opening_times" name="opening_times" required
             placeholder="e.g. 7:00 AM - 6:00 PM daily" value="<?= h($place['opening_times']) ?>">
    </div>
    <div class="field">
      <label for="distance_km">Distance from Kekirawa (km)</label>
      <input type="number" step="0.1" id="distance_km" name="distance_km" required value="<?= h($place['distance_km']) ?>">
    </div>
  </div>

  <div class="field">
    <label for="travel_tips">Travel tips</label>
    <textarea id="travel_tips" name="travel_tips"><?= h($place['travel_tips']) ?></textarea>
  </div>

  <div class="row-2">
    <div class="field">
      <label for="latitude">Latitude</label>
      <input type="text" id="latitude" name="latitude" required value="<?= h($place['latitude']) ?>">
    </div>
    <div class="field">
      <label for="longitude">Longitude</label>
      <input type="text" id="longitude" name="longitude" required value="<?= h($place['longitude']) ?>">
    </div>
  </div>
  <p style="font-family:var(--font-mono); font-size:0.75rem; color:var(--sand-dim); margin-top:-8px;">
    Tip: right-click a location on <a href="https://www.openstreetmap.org" target="_blank">openstreetmap.org</a> and choose "Show address" to get exact coordinates.
  </p>

  <button class="btn solid" type="submit">Save place</button>
</form>
