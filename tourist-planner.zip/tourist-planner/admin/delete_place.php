<?php
require_once __DIR__ . '/../includes/functions.php';
require_admin();

$id = isset($_GET['id']) ? (int)$_GET['id'] : 0;

if ($id) {
    $db = get_db();
    $stmt = $db->prepare('DELETE FROM places WHERE id = ?');
    $stmt->execute([$id]);
}

header('Location: dashboard.php?deleted=1');
exit;
