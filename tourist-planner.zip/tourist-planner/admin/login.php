<?php
require_once __DIR__ . '/../includes/functions.php';
$in_admin = true;
$page_title = 'Admin Login';
$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = trim($_POST['username'] ?? '');
    $password = $_POST['password'] ?? '';

    $db = get_db();
    $stmt = $db->prepare('SELECT * FROM admin_users WHERE username = ?');
    $stmt->execute([$username]);
    $user = $stmt->fetch();

    if ($user && password_verify($password, $user['password_hash'])) {
        $_SESSION['admin_id'] = $user['id'];
        $_SESSION['admin_username'] = $user['username'];
        header('Location: dashboard.php');
        exit;
    } else {
        $error = 'Incorrect username or password.';
    }
}

include __DIR__ . '/../includes/header.php';
?>

<div class="login-box">
  <h1>Admin login</h1>
  <?php if ($error): ?><div class="alert err"><?= h($error) ?></div><?php endif; ?>
  <form class="stack" method="post">
    <div class="field">
      <label for="username">Username</label>
      <input type="text" id="username" name="username" required autofocus>
    </div>
    <div class="field">
      <label for="password">Password</label>
      <input type="password" id="password" name="password" required>
    </div>
    <button class="btn solid" type="submit">Log in</button>
  </form>
  <p style="font-family:var(--font-mono); font-size:0.75rem; color:var(--sand-dim); margin-top:16px;">
    Default seed login: admin / admin123 — change this in the database before submitting.
  </p>
</div>

<?php include __DIR__ . '/../includes/footer.php'; ?>
