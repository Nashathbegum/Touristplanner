<?php
require_once __DIR__ . '/../includes/functions.php';
$in_admin = true;
require_admin();

$page_title = 'Add Place';
$categories = all_categories();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $db = get_db();
    $stmt = $db->prepare(
        'INSERT INTO places (name, category_id, description, opening_times, travel_tips, distance_km, latitude, longitude)
         VALUES (?, ?, ?, ?, ?, ?, ?, ?)'
    );
    $stmt->execute([
        trim($_POST['name']),
        (int)$_POST['category_id'],
        trim($_POST['description']),
        trim($_POST['opening_times']),
        trim($_POST['travel_tips']),
        (float)$_POST['distance_km'],
        (float)$_POST['latitude'],
        (float)$_POST['longitude'],
    ]);

    header('Location: dashboard.php?saved=1');
    exit;
}

include __DIR__ . '/../includes/header.php';
?>

<h1>Add a new place</h1>
<?php include __DIR__ . '/_place_form.php'; ?>

<?php include __DIR__ . '/../includes/footer.php'; ?>
