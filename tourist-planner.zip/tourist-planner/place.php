<?php
require_once __DIR__ . '/includes/functions.php';

$id = isset($_GET['id']) ? (int)$_GET['id'] : 0;
$place = get_place($id);

if (!$place) {
    http_response_code(404);
    $page_title = 'Not found';
    include __DIR__ . '/includes/header.php';
    echo '<div class="empty-state"><p>That place could not be found.</p><a class="btn" href="index.php">Back to list</a></div>';
    include __DIR__ . '/includes/footer.php';
    exit;
}

$page_title = $place['name'];
$in_plan = in_array((int)$place['id'], plan_ids(), true);
include __DIR__ . '/includes/header.php';
?>

<a href="index.php" style="font-family:var(--font-mono);font-size:0.8rem;">&larr; Back to all places</a>

<div class="detail-head">
  <div>
    <span class="cat"><?= h($place['category_name']) ?></span>
    <h1><?= h($place['name']) ?></h1>
  </div>
  <?php if ($in_plan): ?>
    <a class="btn" href="add_to_plan.php?id=<?= (int)$place['id'] ?>&action=remove&redirect=place">&#10003; In your plan — remove</a>
  <?php else: ?>
    <a class="btn solid" href="add_to_plan.php?id=<?= (int)$place['id'] ?>&redirect=place">+ Add to one-day plan</a>
  <?php endif; ?>
</div>

<div class="detail-grid">
  <div>
    <p><?= nl2br(h($place['description'])) ?></p>

    <ul class="facts">
      <li><span class="label">Opening times</span><?= h($place['opening_times']) ?></li>
      <li><span class="label">Distance from Kekirawa</span><?= h($place['distance_km']) ?> km</li>
      <?php if ($place['travel_tips']): ?>
        <li><span class="label">Travel tips</span><?= nl2br(h($place['travel_tips'])) ?></li>
      <?php endif; ?>
      <li><span class="label">Category</span><?= h($place['category_name']) ?></li>
    </ul>
  </div>

  <div>
    <div id="map"></div>
    <p style="margin-top:10px;">
      <a class="btn small" target="_blank"
         href="https://www.openstreetmap.org/directions?from=&to=<?= h($place['latitude']) ?>%2C<?= h($place['longitude']) ?>">
        Get directions
      </a>
    </p>
  </div>
</div>

<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.9.4/leaflet.min.css">
<script src="https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.9.4/leaflet.min.js"></script>
<script>
  const map = L.map('map').setView([<?= (float)$place['latitude'] ?>, <?= (float)$place['longitude'] ?>], 13);
  L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
    attribution: '&copy; OpenStreetMap contributors'
  }).addTo(map);
  L.marker([<?= (float)$place['latitude'] ?>, <?= (float)$place['longitude'] ?>])
    .addTo(map)
    .bindPopup(<?= json_encode($place['name']) ?>)
    .openPopup();
</script>

<?php include __DIR__ . '/includes/footer.php'; ?>
