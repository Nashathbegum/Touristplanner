-- ============================================================
-- Local Tourist Day-Visit Planner — Database Schema
-- Import this whole file in phpMyAdmin (or `mysql -u root -p < schema.sql`)
-- It creates the database, tables, an admin login, and 10 sample
-- places of interest. EDIT THE SEED DATA to match your own
-- locality and stakeholder research before submitting.
-- ============================================================

CREATE DATABASE IF NOT EXISTS tourist_planner CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE tourist_planner;

DROP TABLE IF EXISTS places;
DROP TABLE IF EXISTS categories;
DROP TABLE IF EXISTS admin_users;

CREATE TABLE categories (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(50) NOT NULL UNIQUE
);

CREATE TABLE places (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(120) NOT NULL,
    category_id INT NOT NULL,
    description TEXT NOT NULL,
    opening_times VARCHAR(120) NOT NULL,
    travel_tips TEXT,
    distance_km DECIMAL(4,1) NOT NULL,
    latitude DECIMAL(10,7) NOT NULL,
    longitude DECIMAL(10,7) NOT NULL,
    image_url VARCHAR(255) DEFAULT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (category_id) REFERENCES categories(id)
);

CREATE TABLE admin_users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(50) NOT NULL UNIQUE,
    password_hash VARCHAR(255) NOT NULL
);

-- Default admin login: username "admin", password "admin123"
-- CHANGE THIS before submitting / deploying anywhere public.
INSERT INTO admin_users (username, password_hash) VALUES
('admin', '$2y$10$92IXUNpkjO0rOQ5by2xL3O.LG5.O0f/vhVLL/7Fdk6X7Kc3nq8eIu');
-- ^ hash for "admin123" (bcrypt)

INSERT INTO categories (name) VALUES
('Religious'), ('Nature'), ('Heritage'), ('Cultural');

-- Sample places within ~25km of Kekirawa, North Central Province.
-- REPLACE / VERIFY distances and details with your own stakeholder research.
INSERT INTO places (name, category_id, description, opening_times, travel_tips, distance_km, latitude, longitude, image_url) VALUES
('Avukana Buddha Statue', 1,
 'A 5th-century, 12-metre standing Buddha statue carved from a single granite rock face, one of the finest examples of ancient Sinhalese sculpture.',
 '7:00 AM - 6:00 PM daily',
 'Best visited early morning before the heat. Small entrance fee. Modest dress required (cover shoulders and knees).',
 12.5, 8.0128, 80.5039, NULL),

('Kalawewa Reservoir', 2,
 'A vast ancient reservoir (wewa) built in the 5th century, now a scenic spot for birdwatching, sunset views, and a quiet lakeside walk.',
 'Open 24 hours (best at sunrise/sunset)',
 'Bring binoculars for birdlife. Roads around the bund can be uneven after rain.',
 10.0, 8.0219, 80.4926, NULL),

('Ritigala Strict Nature Reserve', 2,
 'A forested mountain reserve with ruins of an ancient monastic hospital and meditation complex hidden among the trees.',
 '6:00 AM - 5:30 PM daily',
 'A licensed guide is recommended for the forest trail. Wear proper walking shoes and carry water.',
 22.0, 8.1167, 80.6167, NULL),

('Vijithapura Raja Maha Vihara', 1,
 'A historic temple linked to one of the earliest fortified cities of ancient Sri Lanka, with an old stupa and quiet meditation grounds.',
 '6:00 AM - 6:00 PM daily',
 'Small, peaceful site — good for a short stop rather than a long visit.',
 14.0, 8.1780, 80.4530, NULL),

('Nachchaduwa Wewa', 2,
 'A large historic reservoir popular for its calm waters, birdlife, and views across the surrounding paddy fields.',
 'Open 24 hours',
 'Good picnic spot; little shade, so visit in the cooler hours.',
 20.5, 8.2500, 80.4333, NULL),

('Kekirawa Town Rajamaha Viharaya', 1,
 'A local town temple with a modest ancient stupa, an easy stop for visitors wanting a glimpse of everyday religious life in the area.',
 '6:00 AM - 7:00 PM daily',
 'Very close to the town centre; easy to combine with a market visit.',
 2.0, 8.0410, 80.6030, NULL),

('Kekirawa Paddy Field Viewpoint', 4,
 'A roadside viewpoint over the surrounding rice paddies, especially scenic during the growing season when the fields turn bright green.',
 'Daylight hours',
 'Best light for photos is early morning or just before sunset.',
 3.5, 8.0500, 80.6100, NULL),

('Aukana Tank Bund Walk', 4,
 'A quiet walking path along the bund of the reservoir near Avukana, giving a feel for everyday village life around the ancient irrigation system.',
 'Daylight hours',
 'Combine with the Avukana Buddha Statue visit since they are close together.',
 12.0, 8.0150, 80.5010, NULL),

('Ihalagama Wewa', 2,
 'A smaller, lesser-known reservoir popular with local fishers, offering a peaceful and uncrowded alternative to the larger tanks.',
 'Open 24 hours',
 'Not well signposted — ask locally for directions or confirm the route in advance.',
 8.0, 8.0600, 80.5700, NULL),

('Kalawewa Sandagiri Seya', 3,
 'A restored ancient stupa on the banks of Kalawewa, believed to date back to the reign of King Dhatusena.',
 '6:00 AM - 6:00 PM daily',
 'Combine with a Kalawewa reservoir visit as they are next to each other.',
 11.0, 8.0270, 80.4890, NULL);
