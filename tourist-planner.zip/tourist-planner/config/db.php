<?php
/**
 * Database connection.
 * Update these four values to match your local MySQL / XAMPP setup.
 */
define('DB_HOST', 'localhost');
define('DB_NAME', 'tourist_planner');
define('DB_USER', 'root');
define('DB_PASS', '');

function get_db() {
    static $pdo = null;
    if ($pdo === null) {
        try {
            $pdo = new PDO(
                'mysql:host=' . DB_HOST . ';dbname=' . DB_NAME . ';charset=utf8mb4',
                DB_USER,
                DB_PASS,
                [
                    PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
                    PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
                ]
            );
        } catch (PDOException $e) {
            die('Database connection failed. Check config/db.php and make sure the '
                . '"tourist_planner" database has been imported. (' . $e->getMessage() . ')');
        }
    }
    return $pdo;
}
