<?php
require_once __DIR__ . '/includes/functions.php';

$page_title = 'My Plan';

// handle reordering
if (isset($_GET['move']) && isset($_GET['dir'])) {
    $ids = plan_ids();
    $idx = array_search((int)$_GET['move'], $ids, true);
    if ($idx !== false) {
        $swap = $_GET['dir'] === 'up' ? $idx - 1 : $idx + 1;
        if ($swap >= 0 && $swap < count($ids)) {
            [$ids[$idx], $ids[$swap]] = [$ids[$swap], $ids[$idx]];
            $_SESSION['plan'] = $ids;
        }
    }
    header('Location: plan.php');
    exit;
}

$ids = plan_ids();
$places = [];
foreach ($ids as $pid) {
    $pl = get_place($pid);
    if ($pl) $places[] = $pl;
}
$total_km = array_sum(array_column($places, 'distance_km'));

include __DIR__ . '/includes/header.php';
?>

<section class="hero">
  <p class="eyebrow">Your itinerary</p>
  <h1>One-day visit plan</h1>
  <p class="lede">Places you've added, in visiting order. Reorder them to match the shape of your day,
  from morning to evening.</p>
</section>

<?php if (!$places): ?>
  <div class="empty-state">
    <p>You haven't added any places yet.</p>
    <p><a class="btn solid" href="index.php">Browse places</a></p>
  </div>
<?php else: ?>

  <div class="arc-wrap">
    <?php
      $w = 900; $h = 220; $n = count($places);
      $pad = 60;
      $usable = $w - 2 * $pad;
    ?>
    <svg viewBox="0 0 <?= $w ?> <?= $h ?>" xmlns="http://www.w3.org/2000/svg">
      <path d="M <?= $pad ?> 180 Q <?= $w/2 ?> 20 <?= $w - $pad ?> 180"
            fill="none" stroke="#D9A94E" stroke-width="2" stroke-dasharray="2 6" />
      <text x="<?= $pad ?>" y="205" fill="#C9BFA6" font-family="IBM Plex Mono, monospace" font-size="12">sunrise</text>
      <text x="<?= $w - $pad - 40 ?>" y="205" fill="#C9BFA6" font-family="IBM Plex Mono, monospace" font-size="12">sunset</text>
      <?php foreach ($places as $i => $p):
          $t = $n > 1 ? $i / ($n - 1) : 0.5;
          $x = $pad + $t * $usable;
          // quadratic bezier y at parameter t for control point (w/2, 20), endpoints y=180
          $y = (1 - $t) * (1 - $t) * 180 + 2 * (1 - $t) * $t * 20 + $t * $t * 180;
      ?>
        <circle cx="<?= $x ?>" cy="<?= $y ?>" r="9" fill="#16342F" stroke="#B5502E" stroke-width="2" />
        <text x="<?= $x ?>" y="<?= $y + 4 ?>" fill="#EFE6D0" font-family="IBM Plex Mono, monospace"
              font-size="11" text-anchor="middle"><?= $i + 1 ?></text>
        <text x="<?= $x ?>" y="<?= $y - 16 ?>" fill="#EFE6D0" font-family="Work Sans, sans-serif"
              font-size="11" text-anchor="middle"><?= h(mb_strimwidth($p['name'], 0, 16, '…')) ?></text>
      <?php endforeach; ?>
    </svg>
  </div>

  <ul class="plan-list">
    <?php foreach ($places as $i => $p): ?>
      <li class="plan-item">
        <div>
          <span class="idx">#<?= $i + 1 ?></span>
          <strong><a href="place.php?id=<?= (int)$p['id'] ?>" style="color:var(--sand);"><?= h($p['name']) ?></a></strong>
          <div class="meta" style="margin-top:4px;"><?= h($p['category_name']) ?> &middot; <?= h($p['distance_km']) ?> km</div>
        </div>
        <div style="display:flex; gap:6px;">
          <?php if ($i > 0): ?><a class="btn small" href="plan.php?move=<?= (int)$p['id'] ?>&dir=up">&uarr;</a><?php endif; ?>
          <?php if ($i < count($places) - 1): ?><a class="btn small" href="plan.php?move=<?= (int)$p['id'] ?>&dir=down">&darr;</a><?php endif; ?>
          <a class="btn small danger" href="add_to_plan.php?id=<?= (int)$p['id'] ?>&action=remove&redirect=plan">Remove</a>
        </div>
      </li>
    <?php endforeach; ?>
  </ul>

  <p style="margin-top:24px; font-family:var(--font-mono); color:var(--sand-dim);">
    <?= count($places) ?> stops &middot; approx. <?= number_format($total_km, 1) ?> km total from Kekirawa
  </p>

<?php endif; ?>

<?php include __DIR__ . '/includes/footer.php'; ?>
