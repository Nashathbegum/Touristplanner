<?php
require_once __DIR__ . '/includes/functions.php';

$id = isset($_GET['id']) ? (int)$_GET['id'] : 0;
$action = $_GET['action'] ?? 'add';
$redirect = $_GET['redirect'] ?? 'index';

if (!isset($_SESSION['plan'])) {
    $_SESSION['plan'] = [];
}

if ($id) {
    if ($action === 'remove') {
        $_SESSION['plan'] = array_values(array_diff($_SESSION['plan'], [$id]));
    } else {
        if (!in_array($id, $_SESSION['plan'], true)) {
            $_SESSION['plan'][] = $id;
        }
    }
}

switch ($redirect) {
    case 'place':
        header('Location: place.php?id=' . $id);
        break;
    case 'plan':
        header('Location: plan.php');
        break;
    default:
        header('Location: index.php');
}
exit;
