<?php
require_once __DIR__ . '/includes/functions.php';

$page_title = 'Places';
$categories = all_categories();
$selected_cat = isset($_GET['category']) ? (int)$_GET['category'] : null;
$places = get_places($selected_cat);

include __DIR__ . '/includes/header.php';
?>

<section class="hero">
  <p class="eyebrow">Kekirawa &middot; North Central Province</p>
  <h1>Plan a one-day visit around Kekirawa</h1>
  <p class="lede">Browse places of interest within 25km of Kekirawa — temples, reservoirs,
  heritage sites and quiet local spots — and build them into a simple day plan.</p>
</section>

<div class="filterbar">
  <a href="index.php" class="<?= !$selected_cat ? 'active' : '' ?>">All</a>
  <?php foreach ($categories as $cat): ?>
    <a href="index.php?category=<?= (int)$cat['id'] ?>"
       class="<?= $selected_cat === (int)$cat['id'] ? 'active' : '' ?>">
      <?= h($cat['name']) ?>
    </a>
  <?php endforeach; ?>
</div>

<?php if (!$places): ?>
  <div class="empty-state">
    <p>No places found for this category yet.</p>
  </div>
<?php else: ?>
  <div class="grid">
    <?php foreach ($places as $p): ?>
      <div class="card">
        <span class="cat"><?= h($p['category_name']) ?></span>
        <h3><a href="place.php?id=<?= (int)$p['id'] ?>" style="color:inherit;text-decoration:none;"><?= h($p['name']) ?></a></h3>
        <p><?= h(mb_strimwidth($p['description'], 0, 110, '…')) ?></p>
        <div class="meta">
          <span><?= h($p['distance_km']) ?> km away</span>
          <span><?= h($p['opening_times']) ?></span>
        </div>
        <div class="actions">
          <a class="btn small" href="place.php?id=<?= (int)$p['id'] ?>">View details</a>
          <a class="btn small solid" href="add_to_plan.php?id=<?= (int)$p['id'] ?>&redirect=index">+ Add to plan</a>
        </div>
      </div>
    <?php endforeach; ?>
  </div>
<?php endif; ?>

<?php include __DIR__ . '/includes/footer.php'; ?>
